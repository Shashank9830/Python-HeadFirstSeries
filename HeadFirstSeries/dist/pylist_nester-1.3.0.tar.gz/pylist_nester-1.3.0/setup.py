from distutils.core import setup

setup (
    
        name            = 'pylist_nester',
        version         = '1.3.0',
        py_modules      = ['pylist_nester'],
        author          = 'shashank9830',
        author_email    = 'notrealemail@fakesite.com',
        url             = 'http://www.shashank9830.github.io/Python-HeadFirstSeries',
        description     = 'A simple printer of nested lists with optional indentations.',

      )